package com.jbsa.library.missinglib;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MissinglibApplicationTests {

	@Test
	void contextLoads() {
	}

}
