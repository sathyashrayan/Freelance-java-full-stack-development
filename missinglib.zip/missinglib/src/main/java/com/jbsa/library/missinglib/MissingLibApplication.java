package com.jbsa.library.missinglib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MissingLibApplication {

	public static void main(String[] args) {
		SpringApplication.run(MissingLibApplication.class, args);
	}

}
