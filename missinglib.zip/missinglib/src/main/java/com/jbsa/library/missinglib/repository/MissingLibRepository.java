package com.jbsa.library.missinglib.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.jbsa.library.missinglib.model.MissingLib;

public interface MissingLibRepository extends MongoRepository<MissingLib, String> {
  List<MissingLib> findByPublished(boolean published);
  List<MissingLib> findByTitleContaining(String title);
}
